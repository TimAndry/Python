from django.apps import AppConfig


class SwordAppConfig(AppConfig):
    name = 'sword_app'
