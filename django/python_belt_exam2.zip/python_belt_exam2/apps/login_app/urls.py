from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^registration$', views.registration),
    url(r'^login$', views.login),
    url(r'^user/(?P<user_id>\d+)$', views.user),
    url(r'^post$', views.post),
    url(r'^add$', views.add),
    url(r'^edit$', views.edit),
    url(r'^update$', views.update),
    url(r'^cancel$', views.cancel),
    url(r'^show/(?P<job_id>\d+)$', views.show),
    url(r'^show2/(?P<newjob_id>\d+)$', views.show2),
    url(r'^getjob$', views.getjob),
    url(r'^done$', views.done),
    url(r'^logout$', views.logout),
]