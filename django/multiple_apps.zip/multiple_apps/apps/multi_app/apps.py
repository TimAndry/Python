from django.apps import AppConfig


class MultiAppConfig(AppConfig):
    name = 'multi_app'
